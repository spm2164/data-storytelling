(function() {
	var margin = { top: 30, left: 30, right: 30, bottom: 30},
	height = 400 - margin.top - margin.bottom,
	width = 780 - margin.left - margin.right;

	console.log("Building chart 2");

	var svg = d3.select("#chart-2")
				.append("svg")
				.attr("height", height + margin.top + margin.bottom)
				.attr("width", width + margin.left + margin.right)
				.append("g")
				.attr("transform", "translate(" + margin.left + "," + margin.top + ")");

	// Create your scales

	// Create a d3.line function

	// Import your data file using d3.queue()

	// Fix up the function definition! It doesn't just get an error...
	function ready(error) {

		// Draw your dots

		// You have many, many datapoints but only need a few lines...
		// how do you group them together?


		// Add your axes
	}
})();