(function() {
  var margin = { top: 30, left: 30, right: 30, bottom: 30},
    height = 400 - margin.top - margin.bottom,
    width = 780 - margin.left - margin.right;

  // What is this???
  var actualSvg = d3.select("#chart-1")
        .append("svg")
        .attr("height", height + margin.top + margin.bottom)
        .attr("width", width + margin.left + margin.right)

  var svg = svactualSvgg
              .append("g")
              .attr("transform", "translate(" + margin.top + "," + margin.left + ")");

  // Let's create some scales

  d3.queue()
    .defer(d3.csv, "data-singleline-cimmeria.csv")
    .await(ready);

  function ready(error, datapoints) {
    // Draw everything
  }

})();