(function () {

	var datapoints = [
		{ age: 17, name: "Mylo", ducks: 200 },
		{ age: 25, name: "Harper", ducks: 125 },
		{ age: 70, name: "Stretchy", ducks: 7 }	
	];

	console.log("This is the console");

	// .append("g")
	//    .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

})();
