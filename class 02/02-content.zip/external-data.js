(function () {

	console.log("This is the console");

	// .append("g")
	//    .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

})();
